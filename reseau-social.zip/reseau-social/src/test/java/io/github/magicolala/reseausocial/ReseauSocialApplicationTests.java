package io.github.magicolala.reseausocial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReseauSocialApplicationTests {

	@Test
	void contextLoads() {
	}

}
