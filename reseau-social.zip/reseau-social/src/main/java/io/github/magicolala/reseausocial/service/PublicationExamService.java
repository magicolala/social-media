package io.github.magicolala.reseausocial.service;

import io.github.magicolala.reseausocial.entity.PublicationExam;

public interface PublicationExamService {

    Object save(PublicationExam publication);

}
