package io.github.magicolala.reseausocial.service;

import io.github.magicolala.reseausocial.entity.Adhere;

public interface AdhereService {
    Adhere save(Long idUnit);
}
