package io.github.magicolala.reseausocial.repository;

import io.github.magicolala.reseausocial.entity.Adhere;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdhereRepository extends JpaRepository<Adhere, Long> {

}
