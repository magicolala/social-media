package io.github.magicolala.reseausocial.service;

public interface UnitService extends GenericService {

}
