package io.github.magicolala.reseausocial.service;

public interface PublicationService extends GenericService {

}
