package io.github.magicolala.reseausocial.security;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginModel {

    private String email;
    private String password;

}
