package io.github.magicolala.reseausocial.security;

public class SecurityProperties {

    public static String SECRET = "wrhIMk5Fq3qUymQfx53Dl5GIcB9ym5Pf";

}
