package io.github.magicolala.reseausocial.service;

import io.github.magicolala.reseausocial.entity.React;

public interface ReactService {

    React save(Long idPublication);

}
